﻿$fragen = Get-Content C:\Users\Soeren\Desktop\Fragen\Fragen.txt
$antworten = Get-Content C:\Users\Soeren\Desktop\Fragen\Antworten.txt
$fragenKonv = 'C:\Users\Soeren\Desktop\Fragen\FragenKonv.txt'

$antworten2 = Get-Content C:\Users\Soeren\Desktop\Fragen\Antworten.txt
$antworten2.GetType() | Format-Table -AutoSize

$id = 0;
$i = 0;

ForEach($frage in $fragen){

        
        $id++;
        $text = '
        fragenUAntworten.setId'+'('+$id+')'+';
        fragenUAntworten.setFragen'+'('+'"'+$frage+'"'+')'+';
        fragenUAntworten.setAntworten'+'('+'"'+$($antworten[$i])+'"'+')'+';
        db.addBook(fragenUAntworten);' | Out-File $fragenKonv -Append
        $i++;

}
